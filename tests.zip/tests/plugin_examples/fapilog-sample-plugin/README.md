# fapilog-sample-plugin

Minimal skeleton to validate separate-package install flows in CI.
